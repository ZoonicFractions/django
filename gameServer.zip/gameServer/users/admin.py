from django.contrib import admin
from .models import Usuario, Registro

# Register your models here.
admin.site.register(Usuario)
admin.site.register(Registro)